#!/usr/bin/env bash

python src/bot.py